// Synthesized Happy Birthday Music Box using Web Audio API

class BirthdayMusicBox {
    constructor() {
        this.audioCtx = null;
        this.isPlaying = false;
        this.tempo = 110; // Beats per minute
        this.nextNoteTime = 0.0;
        this.noteIndex = 0;
        this.timerId = null;
        
        // Happy Birthday Melody in C major
        // Note structure: [noteName, pitchOctave, durationInBeats]
        // Durations: 0.75 dot, 0.25 sixteenth, 1.0 quarter, 2.0 half
        this.melody = [
            ['C', 4, 0.75], ['C', 4, 0.25], ['D', 4, 1.0], ['C', 4, 1.0], ['F', 4, 1.0], ['E', 4, 2.0], // Happy birthday to you
            ['C', 4, 0.75], ['C', 4, 0.25], ['D', 4, 1.0], ['C', 4, 1.0], ['G', 4, 1.0], ['F', 4, 2.0], // Happy birthday to you
            ['C', 4, 0.75], ['C', 4, 0.25], ['C', 5, 1.0], ['A', 4, 1.0], ['F', 4, 1.0], ['E', 4, 1.0], ['D', 4, 1.0], // Happy birthday dear Faisal
            ['A#', 4, 0.75], ['A#', 4, 0.25], ['A', 4, 1.0], ['F', 4, 1.0], ['G', 4, 1.0], ['F', 4, 2.0], // Happy birthday to you
            ['-', 0, 1.0] // Brief pause before repeat
        ];

        // Frequency mapping
        this.noteFreqs = {
            'C': 261.63,
            'C#': 277.18,
            'D': 293.66,
            'D#': 311.13,
            'E': 329.63,
            'F': 349.23,
            'F#': 369.99,
            'G': 392.00,
            'G#': 415.30,
            'A': 440.00,
            'A#': 466.16,
            'B': 493.88,
            'C5': 523.25
        };
    }

    getFrequency(noteName, octave) {
        if (noteName === '-') return 0;
        
        let freq = this.noteFreqs[noteName];
        if (octave === 5 && noteName === 'C') {
            return this.noteFreqs['C5'];
        }
        return freq;
    }

    init() {
        if (this.audioCtx) return;
        
        // Create context
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        this.audioCtx = new AudioContextClass();
    }

    start() {
        this.init();
        if (this.audioCtx.state === 'suspended') {
            this.audioCtx.resume();
        }
        
        if (this.isPlaying) return;
        
        this.isPlaying = true;
        this.nextNoteTime = this.audioCtx.currentTime + 0.1;
        this.noteIndex = 0;
        
        // Start scheduler loop
        this.scheduler();
    }

    stop() {
        this.isPlaying = false;
        if (this.timerId) {
            clearTimeout(this.timerId);
        }
    }

    scheduler() {
        if (!this.isPlaying) return;

        // Schedule notes ahead
        while (this.nextNoteTime < this.audioCtx.currentTime + 0.3) {
            this.scheduleNote(this.noteIndex, this.nextNoteTime);
            this.advanceNote();
        }
        
        // Run scheduler loop every 50ms
        this.timerId = setTimeout(() => this.scheduler(), 50);
    }

    advanceNote() {
        const beatDuration = 60.0 / this.tempo;
        const currentNote = this.melody[this.noteIndex];
        const duration = currentNote[2] * beatDuration;
        
        this.nextNoteTime += duration;
        this.noteIndex = (this.noteIndex + 1) % this.melody.length;
    }

    scheduleNote(index, time) {
        const note = this.melody[index];
        const noteName = note[0];
        const octave = note[1];
        const durationInBeats = note[2];
        const beatDuration = 60.0 / this.tempo;
        const duration = durationInBeats * beatDuration;

        const freq = this.getFrequency(noteName, octave);
        if (freq === 0) return; // Rest

        // Synthesize Music Box Sound: Oscillators + Gain Envelope
        const osc1 = this.audioCtx.createOscillator();
        const osc2 = this.audioCtx.createOscillator(); // Subharmonic for richness
        const gainNode = this.audioCtx.createGain();

        // Music Box style: Triangle + Sine mix
        osc1.type = 'triangle';
        osc1.frequency.value = freq;

        // Add a gentle second oscillator one octave higher (subtle chime shimmer)
        osc2.type = 'sine';
        osc2.frequency.value = freq * 2;
        
        // Envelope: Instant pluck, slow decay (music box style)
        gainNode.gain.setValueAtTime(0, time);
        // Pluck start
        gainNode.gain.linearRampToValueAtTime(0.2, time + 0.01);
        // Exponential decay
        gainNode.gain.exponentialRampToValueAtTime(0.0001, time + duration - 0.05);

        // Connect
        osc1.connect(gainNode);
        osc2.connect(gainNode);
        gainNode.connect(this.audioCtx.destination);

        // Start & Stop
        osc1.start(time);
        osc2.start(time);
        osc1.stop(time + duration);
        osc2.stop(time + duration);
    }

    toggle() {
        if (this.isPlaying) {
            this.stop();
            return false;
        } else {
            this.start();
            return true;
        }
    }

    playChime() {
        this.init();
        if (this.audioCtx.state === 'suspended') {
            this.audioCtx.resume();
        }
        
        const now = this.audioCtx.currentTime;
        // Clean ascending major chord arpeggio (C5 - E5 - G5) like a magical fairy chime
        const notes = [523.25, 659.25, 783.99]; 
        notes.forEach((freq, idx) => {
            const time = now + idx * 0.08;
            
            const osc = this.audioCtx.createOscillator();
            const gainNode = this.audioCtx.createGain();
            
            osc.type = 'sine'; // Pure sine for clean crystalline bell tone
            osc.frequency.value = freq;
            
            gainNode.gain.setValueAtTime(0, time);
            gainNode.gain.linearRampToValueAtTime(0.12, time + 0.01);
            gainNode.gain.exponentialRampToValueAtTime(0.0001, time + 0.4);
            
            osc.connect(gainNode);
            gainNode.connect(this.audioCtx.destination);
            
            osc.start(time);
            osc.stop(time + 0.5);
        });
    }

    playGiftSound() {
        this.init();
        if (this.audioCtx.state === 'suspended') {
            this.audioCtx.resume();
        }
        
        const now = this.audioCtx.currentTime;
        // Warm romantic arpeggio sweep (F4 - A4 - C5 - F5 - C5 - A4 - F4) representing Omaima's style
        const notes = [349.23, 440.00, 523.25, 698.46, 523.25, 440.00, 349.23];
        notes.forEach((freq, idx) => {
            const time = now + idx * 0.09; // fast romantic sweep
            
            const osc1 = this.audioCtx.createOscillator();
            const osc2 = this.audioCtx.createOscillator(); // Subharmonic for warmth
            const gainNode = this.audioCtx.createGain();
            
            osc1.type = 'triangle';
            osc1.frequency.value = freq;
            
            osc2.type = 'sine';
            osc2.frequency.value = freq / 2; // Warm lower octave
            
            gainNode.gain.setValueAtTime(0, time);
            gainNode.gain.linearRampToValueAtTime(0.15, time + 0.015);
            gainNode.gain.exponentialRampToValueAtTime(0.0001, time + 0.5);
            
            osc1.connect(gainNode);
            osc2.connect(gainNode);
            gainNode.connect(this.audioCtx.destination);
            
            osc1.start(time);
            osc2.start(time);
            osc1.stop(time + 0.6);
            osc2.stop(time + 0.6);
        });
    }
}

// Global Music Box Instance
const musicBox = new BirthdayMusicBox();
